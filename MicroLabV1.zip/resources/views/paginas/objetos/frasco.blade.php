<div class="vaso draggable drag resizable-element v1" description="Frasco con agua">1
	<div class="tapa_vaso"></div>
	<div class="brillo_vaso"></div>
	<div class="agua_vaso"></div>
</div>

<div class="vaso draggable drag resizable-element v2" description="Frasco con agua">2
	<div class="tapa_vaso"></div>
	<div class="brillo_vaso"></div>
	<div class="agua_vaso"></div>
</div>
