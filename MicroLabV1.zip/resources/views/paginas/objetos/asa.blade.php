    <div class="asa1-container draggable drag" description="Asa Circular">
        <div class="mango_asa_1"></div>
        <div class="asa_1"></div>
    </div>