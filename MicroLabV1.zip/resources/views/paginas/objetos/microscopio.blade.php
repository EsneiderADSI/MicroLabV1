<div class="microscopio draggable drag" description="Microscopio">
	<img src="{{ asset('assets\modulos\practica1\microscopio.png')}}" width="200px">
</div>
