    <div class="gotero draggable drag" description="Gotero">
        <div class="cuerpo_gotero"></div>
        <div class="tapa_gotero">
            <div class="detalle-tapa_gotero"></div>
            <div class="detalle-tapa_gotero"></div>
        </div>
        <div class="cuello_gotero"></div>
        <div class="punta_gotero"></div>
        <div class="reflejo_gotero"></div>
    </div>