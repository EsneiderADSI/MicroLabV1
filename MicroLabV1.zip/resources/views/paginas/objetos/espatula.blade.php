    <div class="draggable drag" description="Espátula">
    <div class="espatula">
        <div class="mango_espatula"></div>
    </div>
    </div>
