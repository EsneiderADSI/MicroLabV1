
<div class="cubreobjetos draggable drag" description="Cubre objetos"></div>