    <div class="mechero-container draggable drag resizable-element" description="Mechero">
        <div class="base"></div>
        <div class="soporte"></div>
        <div class="conector"></div>
        <div class="manguera"></div>
        <div class="cuello"></div>
        <div class="llama"></div>
    </div>