    <div class="autoclave-container draggable drag" description="Autoclave">
         <div class="cuerpo">
            <div class="panel">
                <div class="boton_autoclave"></div>
                <div class="boton_autoclave_2"></div>
            </div>
            <div class="puerta">
                <div class="ventana_autoclave"></div>
                <div class="manija_autoclave"></div>
            </div>
            <div class="temperatura_autoclave">0°C</div>
        </div>
    </div>
<?php /**PATH C:\xampp\htdocs\MicroLabV1\resources\views/paginas/modulo-1-objetos/autoclave.blade.php ENDPATH**/ ?>