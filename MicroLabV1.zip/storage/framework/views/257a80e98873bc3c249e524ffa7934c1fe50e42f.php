    <div class="medio_cultivo_caldo tioglicolato draggable drag" description="Caldo tioglicolato" color="#3498db">
        <div class="borde-superior_botella"></div>
        <div class="brillo_botella_caldo"></div>
        <div class="tapa_botella_caldo"></div>
        <div class="liquido_botella_caldo" style="background-color: rgba(52, 152, 219, 1);"></div>
        <div class="texto-botella_caldo">TG</div>
    </div>

    <div class="medio_cultivo_caldo tetrationato draggable drag" description="Caldo tetrationato" color="#583ba6">
        <div class="borde-superior_botella"></div>
        <div class="brillo_botella_caldo"></div>
        <div class="tapa_botella_caldo"></div>
        <div class="liquido_botella_caldo" style="background-color: rgba(124, 77, 255, 0.6);"></div>
        <div class="texto-botella_caldo">TT</div>
    </div>

    <div class="medio_cultivo_caldo Muller-Kauffman draggable drag" description="Caldo Muller-Kauffman" color="#a69a31">
        <div class="borde-superior_botella"></div>
        <div class="brillo_botella_caldo"></div>
        <div class="tapa_botella_caldo"></div>
        <div class="liquido_botella_caldo" style="background-color: rgba(255, 235, 59, 0.6);"></div>
        <div class="texto-botella_caldo">MK</div>
    </div>


    <div class="medio_cultivo_caldo peptonada draggable drag" description="Agua peptonada" color="#949494">
        <div class="borde-superior_botella"></div>
        <div class="brillo_botella_caldo"></div>
        <div class="tapa_botella_caldo"></div>
        <div class="liquido_botella_caldo" style="background-color: rgba(224, 224, 224, 0.6);"></div>
        <div class="texto-botella_caldo">AP</div>
    </div>
<?php /**PATH C:\xampp\htdocs\MicroLabV1\resources\views/paginas/objetos/medios_de_cultivo_caldos.blade.php ENDPATH**/ ?>