    <div class="gotero draggable drag" description="Gotero">
        <div class="cuerpo_gotero"></div>
        <div class="tapa_gotero">
            <div class="detalle-tapa_gotero"></div>
            <div class="detalle-tapa_gotero"></div>
        </div>
        <div class="cuello_gotero"></div>
        <div class="punta_gotero"></div>
        <div class="reflejo_gotero"></div>
    </div><?php /**PATH C:\xampp\htdocs\MicroLabV1\resources\views/paginas/objetos/gotero.blade.php ENDPATH**/ ?>