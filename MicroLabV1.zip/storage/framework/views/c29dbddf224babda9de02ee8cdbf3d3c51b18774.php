    <div class="cabina-container draggable drag" description="Cabina de Flujo">
        <div class="cabina-superior">
            <div></div>
            <div class="panel_de_control_cf"></div>
        </div>
        <div class="puerta-vidrio_cf"></div>
        <div class="panel-interno_cf"></div>
        <div class="borde-inferior_cf"></div>
        <div class="indicador_cf"></div>
        <div class="patas_cf"></div>
        <div class="patas_cf pata-derecha_cf"></div>
        <div class="screen_cabina"></div>
    </div><?php /**PATH C:\xampp\htdocs\MicroLabV1\resources\views/paginas/modulo-1-objetos/cabina-de-flujo.blade.php ENDPATH**/ ?>