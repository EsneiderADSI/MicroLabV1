    <div class="portaobjetos draggable drag" description="Porta Objetos">
        <div class="brillo"></div>
    </div>


<?php /**PATH C:\xampp\htdocs\MicroLabV1\resources\views/paginas/objetos/portaobjetos.blade.php ENDPATH**/ ?>