    <div class="erlenmeyer draggable drag resizable" id="erlenmeyer" description="Erlenmeyer">
        <div class="borde-superior_erlenmeyer"></div>
        <div class="brillo_erlenmeyer"></div>
        <div class="agua_erlenmeyer"></div>
    </div><?php /**PATH C:\xampp\htdocs\MicroLabV1\resources\views/paginas/modulo-1-objetos/erlenmeyer.blade.php ENDPATH**/ ?>