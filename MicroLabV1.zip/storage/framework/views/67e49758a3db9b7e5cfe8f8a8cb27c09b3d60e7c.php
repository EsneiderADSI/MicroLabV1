    <div class="asa2-container draggable drag" description="Asa Triángular">
        <div class="mango_asa_2"></div>
        <div class="asa_2"></div>
    </div><?php /**PATH C:\xampp\htdocs\MicroLabV1\resources\views/paginas/objetos/asa2.blade.php ENDPATH**/ ?>