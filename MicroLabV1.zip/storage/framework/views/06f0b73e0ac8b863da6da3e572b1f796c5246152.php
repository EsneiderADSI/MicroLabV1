    <div class="asa1-container draggable drag" description="Asa Circular">
        <div class="mango_asa_1"></div>
        <div class="asa_1"></div>
    </div><?php /**PATH C:\xampp\htdocs\MicroLabV1\resources\views/paginas/modulo-1-objetos/asa.blade.php ENDPATH**/ ?>