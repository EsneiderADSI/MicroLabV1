<div class="phmetro draggable drag resizable-element" description="PH Metro">
    <div class="phmetro-cabeza">
        <div class="pantalla_phmetro">0.0</div>
        <div class="boton_phmetro"></div>
    </div>
    <div class="phmetro-sonda_phmetro">
        <div class="detalle-sonda_phmetro"></div>
    </div>
</div><?php /**PATH C:\xampp\htdocs\MicroLabV1\resources\views/paginas/modulo-1-objetos/phmetro.blade.php ENDPATH**/ ?>