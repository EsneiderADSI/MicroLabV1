<div tipo="microorganismo" name="escherichia_coli" class="microorganismo draggable drag" description="Escherichia coli"></div>
<div tipo="microorganismo" name="staphylococcus_aureus" class="microorganismo draggable drag" description="Staphylococcus aureus"></div>
<div tipo="microorganismo" name="bacillus_subtilis" class="microorganismo draggable drag" description="Bacillus subtilis"></div>
<div tipo="microorganismo" name="streptococcus_pyogenes" class="microorganismo draggable drag" description="Streptococcus pyogenes"></div>
<div tipo="microorganismo" name="pseudomonas_aeruginosa" class="microorganismo draggable drag" description="Pseudomonas aeruginosa"></div>
<div tipo="microorganismo" name="lactobacillus_acidophilus" class="microorganismo draggable drag" description="Lactobacillus acidophilus"></div>
<div tipo="microorganismo" name="candida_albicans" class="microorganismo draggable drag" description="Candida albicans"></div><?php /**PATH C:\xampp\htdocs\MicroLabV1\resources\views/paginas/objetos/microorganismos.blade.php ENDPATH**/ ?>