    <div class="plancha-container draggable drag resizable-element" description="Calentadora">
        <div class="plancha">
            <div class="top-plate"></div>
            <div class="knob">
                <div class="knob-indicator"></div>
            </div>
            <div class="knob knob2">
                <div class="knob-indicator"></div>
            </div>
            <div class="legs-plancha leg-plancha-left"></div>
            <div class="legs-plancha leg-plancha-right"></div>
        </div>
    </div><?php /**PATH C:\xampp\htdocs\MicroLabV1\resources\views/paginas/modulo-1-objetos/plancha-calentamiento.blade.php ENDPATH**/ ?>