<div class="microscopio draggable drag" description="Microscopio">
	<img src="<?php echo e(asset('assets\modulos\practica1\microscopio.png')); ?>" width="200px">
</div>
<?php /**PATH C:\xampp\htdocs\MicroLabV1\resources\views/paginas/modulo-1-objetos/microscopio.blade.php ENDPATH**/ ?>