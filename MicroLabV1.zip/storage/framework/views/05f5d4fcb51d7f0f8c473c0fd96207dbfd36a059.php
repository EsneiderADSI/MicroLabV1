
<div class="cubreobjetos draggable drag" description="Cubre objetos"></div><?php /**PATH C:\xampp\htdocs\MicroLabV1\resources\views/paginas/modulo-1-objetos/cubreobjetos.blade.php ENDPATH**/ ?>