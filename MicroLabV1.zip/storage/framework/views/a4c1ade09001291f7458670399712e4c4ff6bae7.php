
<div class="petridish_pre draggable drag pm1" description="Microorganismo 1">
    <div class="shine_petridish_pre"></div>
</div>
<div class="petridish_pre draggable drag pm2" description="Microorganismo 2">
    <div class="shine_petridish_pre"></div>
</div>
<div class="petridish_pre draggable drag pm3" description="Microorganismo 3">
    <div class="shine_petridish_pre"></div>
</div>
<?php /**PATH C:\xampp\htdocs\MicroLabV1\resources\views/paginas/modulo-1-objetos/placa-petri-preparada.blade.php ENDPATH**/ ?>