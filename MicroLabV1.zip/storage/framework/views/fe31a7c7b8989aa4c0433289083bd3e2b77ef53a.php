    <div class="petridish draggable drag p1" description="Placa de petri 1">1
       <div class="shine_petridish"></div>
    </div>

   <div class="petridish draggable drag p2" description="Placa de petri 2">2
       <div class="shine_petridish"></div>
    </div>

   <div class="petridish draggable drag p3" description="Placa de petri 3">3
       <div class="shine_petridish"></div>
    </div>

   <div class="petridish draggable drag p4" description="Placa de petri 4">4
       <div class="shine_petridish"></div>
    </div>

   <div class="petridish draggable drag p5" description="Placa de petri 5">5
       <div class="shine_petridish"></div>
    </div>

   <div class="petridish draggable drag p6" description="Placa de petri 6">6
       <div class="shine_petridish"></div>
    </div><?php /**PATH C:\xampp\htdocs\MicroLabV1\resources\views/paginas/modulo-1-objetos/placa-petri.blade.php ENDPATH**/ ?>