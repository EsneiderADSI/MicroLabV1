
<div class="cubreobjetos draggable drag" description="Cubre objetos"></div><?php /**PATH C:\xampp\htdocs\MicroLabV1\resources\views/paginas/objetos/cubreobjetos.blade.php ENDPATH**/ ?>