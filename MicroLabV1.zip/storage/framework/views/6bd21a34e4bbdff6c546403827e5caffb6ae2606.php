    <div class="mechero-container draggable drag resizable-element" description="Mechero">
        <div class="base"></div>
        <div class="soporte"></div>
        <div class="conector"></div>
        <div class="manguera"></div>
        <div class="cuello"></div>
        <div class="llama"></div>
    </div><?php /**PATH C:\xampp\htdocs\MicroLabV1\resources\views/paginas/objetos/mechero.blade.php ENDPATH**/ ?>