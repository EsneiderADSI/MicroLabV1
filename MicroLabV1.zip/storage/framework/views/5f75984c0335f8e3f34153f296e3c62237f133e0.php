<div tipo="medio_cultivo" color="#7f8c8d" value="0" name="agar_chromocult" class="medio_cultivo draggable drag" description="Agar Chromocult"></div>
<div tipo="medio_cultivo" color="#27ae60" value="0" name="agar_m-HPC" class="medio_cultivo draggable drag" description="Agar m-HPC"></div>
<div tipo="medio_cultivo" color="#2980b9" value="0" name="agar_nutritivo" class="medio_cultivo draggable drag" description="Agar nutritivo"></div>
<div tipo="medio_cultivo" color="#c0392b" value="0" name="agar_sangre" class="medio_cultivo draggable drag" description="Agar Sangre"></div>
<div tipo="medio_cultivo" color="#8e44ad" value="0" name="agar_macConkey" class="medio_cultivo draggable drag" description="Agar MacConkey"></div>
<div tipo="medio_cultivo" color="#d35400" value="0" name="agar_LB" class="medio_cultivo draggable drag" description="Agar LB"></div>
<div tipo="medio_cultivo" color="#f39c12" value="0" name="agar_Papa_Dextrosa" class="medio_cultivo draggable drag" description="Agar Papa Dextrosa"></div><?php /**PATH C:\xampp\htdocs\MicroLabV1\resources\views/paginas/objetos/medios_de_cultivo.blade.php ENDPATH**/ ?>