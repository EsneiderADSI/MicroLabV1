<div class="vaso draggable drag resizable-element v1" description="Frasco con agua">1
	<div class="tapa_vaso"></div>
	<div class="brillo_vaso"></div>
	<div class="agua_vaso"></div>
</div>

<div class="vaso draggable drag resizable-element v2" description="Frasco con agua">2
	<div class="tapa_vaso"></div>
	<div class="brillo_vaso"></div>
	<div class="agua_vaso"></div>
</div>
<?php /**PATH C:\xampp\htdocs\MicroLabV1\resources\views/paginas/modulo-1-objetos/frasco.blade.php ENDPATH**/ ?>