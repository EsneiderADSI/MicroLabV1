    <div class="draggable drag" description="Espátula">
    <div class="espatula">
        <div class="mango_espatula"></div>
    </div>
    </div>
<?php /**PATH C:\xampp\htdocs\MicroLabV1\resources\views/paginas/objetos/espatula.blade.php ENDPATH**/ ?>