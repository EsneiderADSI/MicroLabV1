    <div class="incubadora-container draggable drag" description="Incubadora">
        <div class="top-panel_incubadora">
            <div class="screen_incubadora">0°</div>
            <div class="knob_incubadora"></div>
        </div>
        <div class="door_incubadora">
            <div class="window_incubadora">
                <div class="shelves_incubadora"></div>
                <div class="shelves_incubadora shelves2_incubadora"></div>
                <div class="shelves_incubadora shelves3_incubadora"></div>
            </div>
        </div>
        <div class="legs_incubadora"></div>
        <div class="legs_incubadora leg-right_incubadora"></div>
    </div><?php /**PATH C:\xampp\htdocs\MicroLabV1\resources\views/paginas/objetos/incubadora.blade.php ENDPATH**/ ?>