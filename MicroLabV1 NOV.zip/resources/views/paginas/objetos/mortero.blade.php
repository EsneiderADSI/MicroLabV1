<div class="mortero-container draggable drag" description="Mortero">
    <div class="mortero"></div>
</div>
