    <div class="asa3_recta-container draggable drag" description="Asa Recta">
        <div class="mango_asa_recta"></div>
    </div>




