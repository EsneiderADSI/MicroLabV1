    <div class="lupa-container draggable drag" description="Lupa">
        <div class="lupa-circle">
            <div class="lupa-handle"></div>
        </div>
    </div>