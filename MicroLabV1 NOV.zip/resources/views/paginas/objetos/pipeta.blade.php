    <div class="pipeta draggable drag" description="Pipeta">
        <div class="bulb_pipeta"></div>
        <div class="stem_pipeta">
            <div class="measurements_pipeta">
                <!-- Generamos 50 marcas de medición -->

            </div>
            <div class="liquid_pipeta"></div>
            <div class="reflection_pipeta"></div>
        </div>
        <div class="tip_pipeta"></div>
    </div>