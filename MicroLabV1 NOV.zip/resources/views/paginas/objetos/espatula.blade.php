    <div class="espatula draggable drag" description="Espátula">
        <div class="mango_espatula"></div>
    </div>


