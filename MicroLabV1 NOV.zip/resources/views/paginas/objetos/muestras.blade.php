<div tipo="muestra" name="aspirina" class="muestra draggable drag" description="Aspirina"></div>
<div tipo="muestra" name="dolex_gripa" class="muestra draggable drag" description="Dólex Gripa"></div>
<div tipo="muestra" name="sevedol" class="muestra draggable drag" description="Sevedol"></div>
