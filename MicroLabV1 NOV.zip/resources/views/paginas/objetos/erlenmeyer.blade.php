    <div class="erlenmeyer draggable drag resizable" id="erlenmeyer" description="Erlenmeyer">
        <div class="borde-superior_erlenmeyer"></div>
        <div class="brillo_erlenmeyer"></div>
        <div class="agua_erlenmeyer"></div>
    </div>