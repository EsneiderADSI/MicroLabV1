    <div class="petridish_p3 draggable drag colonia_crecida utilizada p1" description="Muestras Fecales 1">1
       <div class="shine_petridish_p3"></div>
    </div>

   <div class="petridish_p3 draggable drag colonia_crecida utilizada p2" description="Muestras Fecales 2">2
       <div class="shine_petridish_p3"></div>
    </div>

   <div class="petridish_p3 draggable drag colonia_crecida utilizada p3" description="Muestras Fecales 3">3
       <div class="shine_petridish_p3"></div>
    </div>