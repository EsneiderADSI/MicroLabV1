  <div class="sink draggable drag" description="Grifo">
    <div class="basin"></div>
    <div class="grifo">
        <div class="tubo_grifo"></div>
        <div class="agua_grifo"></div>
    </div>
</div>