  <div class="mclinica">
    <div class="piel draggable drag" description="Piel">
      <div class="mc skin"></div>
    </div>
    <div class="unia draggable drag" description="Uña">
      <div class="mc nail"></div>
    </div>
    <div class="caspa draggable drag" description="Caspa">
      <div class="mc dandruff"></div>
    </div>
  </div>