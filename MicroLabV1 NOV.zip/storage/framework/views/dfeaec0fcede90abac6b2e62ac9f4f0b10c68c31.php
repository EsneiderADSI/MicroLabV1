
<div class="petridish_pre_prac2 draggable drag pm1 resizable-element" description="Microorganismo 1">
    <div class="shine_petridish_pre_prac2"></div>
</div>
<div class="petridish_pre_prac2 draggable drag pm2 resizable-element" description="Microorganismo 2">
    <div class="shine_petridish_pre_prac2"></div>
</div>
<div class="petridish_pre_prac2 draggable drag pm3 resizable-element" description="Microorganismo 3">
    <div class="shine_petridish_pre_prac2"></div>
</div>
<?php /**PATH C:\xampp\htdocs\MicroLabV1\resources\views/paginas/objetos/practica2/placa-petri-preparada-p2.blade.php ENDPATH**/ ?>