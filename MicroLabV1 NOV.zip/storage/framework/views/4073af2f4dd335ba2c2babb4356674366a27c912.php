    <div class="petridish_p2 draggable drag colonia_crecida utilizada p1" description="Placa de petri 1">1
       <div class="shine_petridish_p2"></div>
    </div>

   <div class="petridish_p2 draggable drag colonia_crecida utilizada p2" description="Placa de petri 2">2
       <div class="shine_petridish_p2"></div>
    </div>

   <div class="petridish_p2 draggable drag colonia_crecida utilizada p3" description="Placa de petri 3">3
       <div class="shine_petridish_p2"></div>
    </div><?php /**PATH C:\xampp\htdocs\MicroLabV1\resources\views/paginas/objetos/practica2/placa-petri-p2.blade.php ENDPATH**/ ?>