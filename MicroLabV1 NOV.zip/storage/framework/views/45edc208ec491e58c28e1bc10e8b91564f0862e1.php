<div tipo="muestra" name="aspirina" class="muestra draggable drag" description="Aspirina"></div>
<div tipo="muestra" name="dolex_gripa" class="muestra draggable drag" description="Dólex Gripa"></div>
<div tipo="muestra" name="sevedol" class="muestra draggable drag" description="Sevedol"></div>
<?php /**PATH C:\xampp\htdocs\MicroLabV1\resources\views/paginas/objetos/muestras.blade.php ENDPATH**/ ?>