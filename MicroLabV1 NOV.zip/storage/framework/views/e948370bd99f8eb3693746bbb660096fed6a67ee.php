    <div class="nevera draggable drag" description="Nevera">
        <div class="nevera-interior">
            <div class="congelador_nevera"></div>
            <div class="cooler_nevera"></div>
            <div class="shelf_nevera shelf_nevera-1"></div>
            <div class="shelf_nevera shelf_nevera-2"></div>
        </div>
        <div class="door_nevera door_nevera-top">
            <div class="handle_nevera handle_nevera-top"></div>
            <div class="logo_nevera"></div>
        </div>
        <div class="door_nevera door_nevera-bottom">
            <div class="handle_nevera handle_nevera-bottom"></div>
        </div>
        <div class="divider_nevera"></div>
    </div>
<?php /**PATH C:\xampp\htdocs\MicroLabV1\resources\views/paginas/objetos/nevera.blade.php ENDPATH**/ ?>