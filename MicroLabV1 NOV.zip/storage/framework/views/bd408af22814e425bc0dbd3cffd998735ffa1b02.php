
<div class="petridish_pre draggable drag pm1" description="Toma Muestra 1">
    <div class="shine_petridish_pre"></div>
</div>
<div class="petridish_pre draggable drag pm2" description="Toma Muestra 2">
    <div class="shine_petridish_pre"></div>
</div>
<div class="petridish_pre draggable drag pm3" description="Toma Muestra 3">
    <div class="shine_petridish_pre"></div>
</div>
<?php /**PATH C:\xampp\htdocs\MicroLabV1\resources\views/paginas/objetos/placa-petri-preparada.blade.php ENDPATH**/ ?>