<div class="mortero-container draggable drag" description="Mortero">
    <div class="mortero"></div>
</div>
<?php /**PATH C:\xampp\htdocs\MicroLabV1\resources\views/paginas/objetos/mortero.blade.php ENDPATH**/ ?>