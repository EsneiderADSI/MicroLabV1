    <div class="lupa-container draggable drag" description="Lupa">
        <div class="lupa-circle">
            <div class="lupa-handle"></div>
        </div>
    </div><?php /**PATH C:\xampp\htdocs\MicroLabV1\resources\views/paginas/objetos/lupa.blade.php ENDPATH**/ ?>