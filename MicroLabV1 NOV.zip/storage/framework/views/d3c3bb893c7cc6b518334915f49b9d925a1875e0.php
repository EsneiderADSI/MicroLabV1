    <div  class="balanza draggable drag" description="Balanza">
        <div class="display_balanza" value="0">0g</div>
        <input type="range" class="peso_slider" min="0" max="500" step="5" value="0">
        <div class="lamina_balanza">LÁMINA</div>
    </div><?php /**PATH C:\xampp\htdocs\MicroLabV1\resources\views/paginas/objetos/balanza.blade.php ENDPATH**/ ?>