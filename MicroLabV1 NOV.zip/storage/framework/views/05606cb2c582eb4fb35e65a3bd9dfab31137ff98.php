  <div class="hongos">

    <div class="pann hongo draggable drag" description="Pan">
      <div class="pan"></div>
    </div>

    <div class="manza hongo draggable drag" description="Manzana">
      <div class="manzana">
        <div class="manzana-leaf"></div>
      </div>
    </div>

    <div class="zana hongo draggable drag" description="Zanahoria">
      <div class="zanahoria">
        <div class="zanahoria-top"></div>
        <div class="zanahoria-body"></div>
      </div>
    </div>

  </div><?php /**PATH C:\xampp\htdocs\MicroLabV1\resources\views/paginas/objetos/practica4/hongos-filamentosos.blade.php ENDPATH**/ ?>