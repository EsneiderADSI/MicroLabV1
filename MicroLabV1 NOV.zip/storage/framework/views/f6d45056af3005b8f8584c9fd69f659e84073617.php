    <div class="asa3_recta-container draggable drag" description="Asa Recta">
        <div class="mango_asa_recta"></div>
    </div>




<?php /**PATH C:\xampp\htdocs\MicroLabV1\resources\views/paginas/objetos/asa3.blade.php ENDPATH**/ ?>