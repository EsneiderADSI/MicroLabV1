    <div class="tubo-ensayo-container_micro draggable drag t1" description="Tubo de Ensayo MCG 1">1
        <div class="tapa-tubo_micro"></div>
        <div class="borde-superior-tubo_micro"></div>
        <div class="lineas-medicion_micro">

        </div>
        <div class="liquido-tubo_micro"></div>
    </div>

    <div class="tubo-ensayo-container_micro draggable drag t2" description="Tubo de Ensayo MCG 2">2
        <div class="tapa-tubo_micro"></div>
        <div class="borde-superior-tubo_micro"></div>
        <div class="lineas-medicion_micro">

        </div>
        <div class="liquido-tubo_micro"></div>
    </div>

    <div class="tubo-ensayo-container_micro draggable drag t3" description="Tubo de Ensayo MCG 3">3
        <div class="tapa-tubo_micro"></div>
        <div class="borde-superior-tubo_micro"></div>
        <div class="lineas-medicion_micro">

        </div>
        <div class="liquido-tubo_micro"></div>
    </div>

    <div class="tubo-ensayo-container_micro draggable drag t3" description="Tubo de Ensayo MCG 3">3
        <div class="tapa-tubo_micro"></div>
        <div class="borde-superior-tubo_micro"></div>
        <div class="lineas-medicion_micro">

        </div>
        <div class="liquido-tubo_micro"></div>
    </div><?php /**PATH C:\xampp\htdocs\MicroLabV1\resources\views/paginas/objetos/tubo-ensayo-microorganismo.blade.php ENDPATH**/ ?>