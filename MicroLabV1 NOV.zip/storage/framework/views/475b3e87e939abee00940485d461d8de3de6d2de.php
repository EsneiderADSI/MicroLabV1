  <div class="sink draggable drag" description="Grifo">
    <div class="basin"></div>
    <div class="grifo">
        <div class="tubo_grifo"></div>
        <div class="agua_grifo"></div>
    </div>
</div><?php /**PATH C:\xampp\htdocs\MicroLabV1\resources\views/paginas/objetos/grifo.blade.php ENDPATH**/ ?>