    <div class="tubo-ensayo-container draggable drag t1" description="Tubo de Ensayo">1
        <div class="tapa-tubo"></div>
        <div class="borde-superior-tubo"></div>
        <div class="lineas-medicion">
            <div></div>
            <div></div>
            <div></div>
            <div></div>
            <div></div>
        </div>
        <div class="liquido-tubo"></div>
    </div>

        <div class="tubo-ensayo-container draggable drag t2" description="Tubo de Ensayo">2
        <div class="tapa-tubo"></div>
        <div class="borde-superior-tubo"></div>
        <div class="lineas-medicion">
            <div></div>
            <div></div>
            <div></div>
            <div></div>
            <div></div>
        </div>
        <div class="liquido-tubo"></div>
    </div>

    <div class="tubo-ensayo-container draggable drag t3" description="Tubo de Ensayo">3
        <div class="tapa-tubo"></div>
        <div class="borde-superior-tubo"></div>
        <div class="lineas-medicion">
            <div></div>
            <div></div>
            <div></div>
            <div></div>
            <div></div>
        </div>
        <div class="liquido-tubo"></div>
    </div>

    <div class="tubo-ensayo-container draggable drag t4" description="Tubo de Ensayo">4
        <div class="tapa-tubo"></div>
        <div class="borde-superior-tubo"></div>
        <div class="lineas-medicion">
            <div></div>
            <div></div>
            <div></div>
            <div></div>
            <div></div>
        </div>
        <div class="liquido-tubo"></div>
    </div><?php /**PATH C:\xampp\htdocs\MicroLabV1\resources\views/paginas/objetos/tubo-ensayo.blade.php ENDPATH**/ ?>